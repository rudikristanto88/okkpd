</body>

    <!-- Plugins Js -->
    <script src="<?= base_url() ?>assets/dashboard/js/app.min.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/form.min.js"></script>

    <script src="<?= base_url() ?>assets/dashboard/js/bundles//multiselect/js/jquery.multi-select.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.js"></script>

    <script src="<?= base_url() ?>assets/dashboard/js/chart.min.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/map.min.js"></script>
    <!-- Custom Js -->
    <script src="<?= base_url() ?>assets/dashboard/js/admin.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/pages/forms/form-wizard.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/pages/forms/advanced-form-elements.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/demo.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/pages/examples/pages.js"></script>
    <script src="<?= base_url() ?>assets/dashboard/js/loading-bar.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/dashboard/js/datatables.min.js"></script>

    <script type="text/javascript" src="<?= base_url() ?>assets/jquery.captcha.basic.min.js"></script>



    <script type="text/javascript">
    $(document).ready(function(){

        $('#table-datatable').DataTable();
    })
    </script>

</html>
