<div class="container" style="margin-top:100px">
  <div class="row">
    <div class="col-md-6 col-md-offset-3" style="text-align:center">
      <div class="">
        <i class="far fa-check-circle" style="font-size: 7em; color: #2ecc71;"></i>
      </div><br/><br/>
      <div class="">
        <div class="alert alert-success">Tautan aktivasi akun telah terkirim. Silahkan masuk ke email anda untuk dapat melakukan aktivasi akun<br/> Waktu kirim email konfirmasi dapat membutuhkan waktu sekitar 5 menit.</div><br/>

        <div class="form-container">
          <a href="<?= base_url() ?>home/pendaftaran_online" class="btn btn-primary">Kembali ke halaman Login</a>
          <br/><br/><br/><br/>
        </div>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/jquery-migrate.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/bootstrap.min.js"></script>

<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/jquery.timeline.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/revslider/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/revslider/js/jquery.themepunch.revolution.min.js"></script>

<!--<script type="text/javascript" src="custom_tools/js/front.customizer.js"></script>
<script type="text/javascript" src="custom_tools/js/skin.customizer.js"></script>-->

<script type="text/javascript" src="<?= base_url() ?>assets/default/js/_packed.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/shortcodes.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/_main.js"></script>

<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/jquery.formstyler.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/jquery.validate.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/vendor/logical.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/default/js/custom.js"></script>
