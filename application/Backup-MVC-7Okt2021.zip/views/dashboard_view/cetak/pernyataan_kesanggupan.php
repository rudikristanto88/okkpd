Pernyataan kesanggupan
