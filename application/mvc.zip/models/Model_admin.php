<?php
class Model_admin extends CI_Model {
  public function insertData($table,$data)
  {
    return $this->db->insert($table, $data);
  }

  public function updateData($table,$valId,$idName,$data){
    $this->db->where($idName, $valId);
    return $this->db->update($table, $data);
  }

  public function getAllData($table){
    $this->db->select("*");
    $this->db->from($table);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDataWhere($table,$where,$value){
    $this->db->select("*");
    $this->db->from($table);
    $this->db->where($where,$value);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getMenu($role)
  {
    $this->db->select("*");
    $this->db->from('menu');
    $this->db->where("kode_role",$role);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDataKota()
  {
    $this->db->select("*");
    $this->db->from('kota');
    $this->db->where("kode_provinsi",'33');
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDataUsaha($id_user)
  {
    $this->db->select("*");
    $this->db->from('identitas_usaha');
    $this->db->where("id_user",$id_user);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDataInspeksi()
  {
    $this->db->select("*");
    $this->db->from('identitas_usaha');
    $this->db->join('layanan',"identitas_usaha.id_identitas_usaha=layanan.id_identitas_usaha");
    $this->db->join('master_layanan',"layanan.kode_layanan=master_layanan.kode_layanan");
    $query = $this->db->get();
    return $query->result_array();
  }


  public function getDataLayanan($value){
    $query = $this->db->query("SELECT *, (Select count(*) from dokumen_layanan where id_layanan = layanan.uid) - (Select count(*) from detail_dokumen where kode_layanan = layanan.kode_layanan) as kekurangan from layanan join master_layanan on layanan.kode_layanan = master_layanan.kode_layanan where layanan.id_identitas_usaha = ".$value." ");
    return $query->result_array();
  }
  public function getAllUser($id_user)
  {
    $this->db->select("*");
    $this->db->from('user');
    $this->db->join('master_role','user.kode_role=master_role.kode_role');
    $where = "user.id_user <> $id_user";
    $where2 = "user.kode_role <> 'pelaku'";
    $this->db->where($where);
    $this->db->where($where2);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDetailSyaratTeknis($layanan)
  {
    $this->db->select("*");
    $this->db->from('detail_syarat_teknis');
    $this->db->join('master_syarat_teknis','detail_syarat_teknis.kode_syarat_teknis=master_syarat_teknis.kode');
    $this->db->where("id_layanan",$layanan);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDetailDokumen($layanan)
  {
    $this->db->select("*");
    $this->db->from('detail_dokumen');
    $this->db->join('master_dokumen','detail_dokumen.kode_dokumen=master_dokumen.kode_dokumen');
    $this->db->where("kode_layanan",$layanan);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDokumen($id_layanan)
  {
    $this->db->select("*");
    $this->db->from('dokumen_layanan');
    $this->db->where("id_layanan",$id_layanan);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDokumenById($id_dokumen)
  {
    $this->db->select("*");
    $this->db->from('dokumen_layanan');
    $this->db->where("id_dokumen",$id_dokumen);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDokumenLevel($level)
  {
    $this->db->select("*");
    $this->db->from('layanan');
    $this->db->join('identitas_usaha',"layanan.id_identitas_usaha=identitas_usaha.id_identitas_usaha");
    $this->db->join('user',"identitas_usaha.id_user=user.id_user");
    $this->db->join('master_layanan',"layanan.kode_layanan=master_layanan.kode_layanan");
    $this->db->where("layanan.status","0");
    $this->db->where("layanan.manager_adm",null);
    $this->db->where("layanan.level",$level);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getDokumenDitolak($level)
  {
    $this->db->select("*");
    $this->db->from('layanan');
    $this->db->join('identitas_usaha',"layanan.id_identitas_usaha=identitas_usaha.id_identitas_usaha");
    $this->db->join('user',"identitas_usaha.id_user=user.id_user");
    $this->db->where("level",$level);
    $this->db->where("layanan.status","1");
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getKomoditas()
  {
    $this->db->select("*");
    $this->db->from('master_komoditas');
    $this->db->order_by('deskripsi',"asc");
    $query = $this->db->get();
    return $query->result_array();
  }
  public function getIdUsaha($id_user)
  {
    $this->db->select("*");
    $this->db->from('identitas_usaha');
    $this->db->where('id_user',$id_user);
    $query = $this->db->get();
    $dat = $query->result_array();
    foreach ($dat as $data);
    return $data['id_identitas_usaha'];
  }
  public function getLastId($tabel,$idtabel)
  {
    $this->db->select("*");
    $this->db->from($tabel);
    $this->db->order_by($idtabel,"asc");
    $this->db->limit(1);
    $query = $this->db->get();
    $result = $query->result_array();
    foreach ($result as $result);
    return $result[$idtabel];
  }

  public function validasi($username,$password,$isPengurus = null)
  {
    $this->db->select("user.id_user,user.kode_role,nama_role,nama_lengkap,username,COALESCE(identitas_usaha.id_identitas_usaha,0,1) as punya_usaha");
    $this->db->from('user');
    $this->db->join('identitas_usaha','user.id_user = identitas_usaha.id_user','left');
    $this->db->join('master_role','user.kode_role = master_role.kode_role');
    $this->db->where("username",$username);
    $this->db->where("password",sha1("Okkpd2018!".$password));

    if($isPengurus){
      $where = "user.kode_role not like '%pelaku%'";
      $this->db->where($where);

    }else{
      $where = "user.kode_role like '%pelaku%'";
      $this->db->where($where);
      $this->db->where("status","1");

    }
    $query = $this->db->get();
    $dat = $query->result_array();

    foreach ($dat as $dat);

    if(sizeof($dat) > 0){
      $this->session->set_userdata("dataLogin",$dat);
      return true;
    }else{
      return false;
    }

  }
}
?>
