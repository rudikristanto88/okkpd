<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url_helper');

	}
	public function index()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation');
		$this->load->view('default/index');
		$this->load->view('default/template/footer');
	}

	public function visi_misi()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/about');
		$this->load->view('default/template/footer');
	}

	public function struktur_organisasi()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/struktur');
		$this->load->view('default/template/footer');
	}

	public function maklumat()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/maklumat');
		$this->load->view('default/template/footer');
	}

	public function tugas_fungsi()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/tugas');
		$this->load->view('default/template/footer');
	}

	public function legalitas()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/legalitas');
		$this->load->view('default/template/footer');
	}

	public function daftar_layanan()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/layanan');
		$this->load->view('default/template/footer');
	}

	public function pendaftaran_online()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/pendaftaran_online');
		$this->load->view('default/template/footer');
	}

	public function hubungi_kami()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/kontak');
		$this->load->view('default/template/footer');
	}

	public function keluhan_saran()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/saran');
		$this->load->view('default/template/footer');
	}

	public function status_perizinan()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/status');
		$this->load->view('default/template/footer');
	}

	public function regulasi()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/regulasi');
		$this->load->view('default/template/footer');
	}

	public function sertifikasi_prima_2()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/prima2');
		$this->load->view('default/template/footer');
	}

	public function sertifikasi_prima_3()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/prima3');
		$this->load->view('default/template/footer');
	}

	public function pendaftaran_psat()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/psat');
		$this->load->view('default/template/footer');
	}

	public function pendaftaran_rumah_kemas()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/rumah_kemas');
		$this->load->view('default/template/footer');
	}

	public function penerbitan_health_certificate()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/hc');
		$this->load->view('default/template/footer');
	}

	public function penerbitan_hygne_sanitation()
	{
		$data['islogin'] = false;

		if($this->session->userdata("dataLogin") != null){
			$data['islogin'] = true;
		}
		$this->load->view('default/template/header',$data);
		$this->load->view('default/template/navigation-small');
		$this->load->view('default/hs');
		$this->load->view('default/template/footer');
	}
}
