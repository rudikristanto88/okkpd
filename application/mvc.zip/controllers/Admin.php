<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  public function __construct()
	{
		parent::__construct();
		$this->load->helper('url_helper');
		$this->load->helper(array('form', 'url'));
		$this->load->library('session');
    $this->load->model('model_user');
		$this->load->model('model_admin');
		$data['datalogin'] = $this->session->userdata("dataLogin");
		$this->menu =  $this->model_user->getMenu($this->saya());

	}

  public function saya(){
		$datalogin = $this->session->userdata("dataLogin");
		return $datalogin['kode_role'];
	}

  public function info_layanan()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/info_layanan',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function akun_pelaku_usaha()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/akun_pelaku_usaha',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function gambar_slider()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/gambar_slider',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tambah_slider()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tambah_slider',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function kontak_kami()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/kontak_kami',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function unit_dinas()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/unit_dinas',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tambah_dinas()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tambah_dinas',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function identitas_kepala_dinas()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/identitas_kepala_dinas',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tautan_terkait()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['tautan'] = $this->model_admin->getAllData("tautan");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tautan_terkait',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tambah_tautan()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tambah_tautan',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function insert_tautan()
	{
		$i = $this->input;
		$nama_tautan= $i->post("nama_tautan");
		$alamat_tautan = $i->post("alamat_tautan");


		$data = array('id_tautan'=>null,
		'nama_tautan'=>$nama_tautan,
		'alamat_tautan'=>$alamat_tautan);

		if($this->model_admin->insertData('tautan',$data)){
			$this->session->set_flashdata("status_registrasi","<div class='alert alert-success'>Tautan berhasil ditambahkan</div>");
			redirect("admin/tautan_terkait","redirect");
		}else{
			$this->session->set_flashdata("status_registrasi","<div class='alert alert-warning'>Tautan gagal ditambahkan</div>");
			redirect("admin/tautan_terkait","redirect");

		}
	}

  public function konsultasi_online()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/konsultasi_online',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function berita()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['berita'] = $this->model_admin->getAllData("berita");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/berita',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tambah_berita()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tambah_berita',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function insert_berita()
	{
		$i = $this->input;
		$judul_berita = $i->post("judul_berita");
		$isi_berita = $i->post("isi_berita");


		$data = array('id_berita'=>null,
		'judul_berita'=>$judul_berita,
		'isi_berita'=>$isi_berita);

		if($this->model_admin->insertData('berita',$data)){
			$this->session->set_flashdata("status_registrasi","<div class='alert alert-success'>Berita berhasil ditambahkan</div>");
			redirect("admin/berita","redirect");
		}else{
			$this->session->set_flashdata("status_registrasi","<div class='alert alert-warning'>Berita gagal ditambahkan</div>");
			redirect("admin/berita","redirect");

		}
	}

  public function cek_status_layanan()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/status_layanan',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function panduan()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/panduan',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tambah_panduan()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tambah_panduan',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function tentang_kami()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/tentang_kami',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_prima_3()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_prima_3',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_prima_2()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_prima_2',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_psat()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_psat',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_rumah_kemas()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_rumah_kemas',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_hc()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_hc',$data);
    $this->load->view('dashboard_view/template/footer');
  }

  public function layanan_hs()
  {
    $data['datalogin'] = $this->session->userdata("dataLogin");
    $data['role'] = $this->model_user->getAllData("master_role");
    $data['kota'] = $this->model_user->getDataKota();
    $this->load->view('dashboard_view/template/header',$data);
    $this->load->view('dashboard_view/template/top_nav');
    $this->load->view('dashboard_view/template/side_nav',$this->menu);
    $this->load->view('dashboard_view/admin/layanan_hs',$data);
    $this->load->view('dashboard_view/template/footer');
  }



}
