<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Roxa - Bootstrap 4 Admin Dashboard Template</title>
    <!-- Favicon-->


<link rel="icon" href="<?= base_url() ?>assets/dashboard/images/favicon.ico" type="image/x-icon">

<!-- Colorpicker Css -->
<link href="<?= base_url() ?>assets/dashboard/js/bundles/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.css" rel="stylesheet" />

<!-- Multi Select Css -->
<link href="<?= base_url() ?>assets/dashboard/js/bundles/multiselect/css/multi-select.css" rel="stylesheet">

<!-- Plugins Core Css -->
<link href="<?= base_url() ?>assets/dashboard/css/app.min.css" rel="stylesheet">
<link href="<?= base_url() ?>assets/dashboard/css/form.min.css" rel="stylesheet">

<!-- Custom Css -->
<link href="<?= base_url() ?>assets/dashboard/css/style.css" rel="stylesheet">
<link href="<?= base_url() ?>assets/dashboard/css/custom.css" rel="stylesheet">

<!-- You can choose a theme from css/styles instead of get all themes -->
<link href="<?= base_url() ?>assets/dashboard/css/styles/all-themes.css" rel="stylesheet" />

<link href="<?= base_url() ?>assets/dashboard/css/style.css" rel="stylesheet" />
<link href="<?= base_url() ?>assets/dashboard/css/pages/extra_pages.css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/dashboard/css/datatables.min.css"/>

<script src="<?= base_url() ?>assets/dashboard/js/jquery.js"></script>




</head>


<body>
    <!-- Page Loader -->
