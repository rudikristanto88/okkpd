<div class="">
  <table>
    <tr>
      <td>No</td>
      <td>: </td>
    </tr>
    <tr>
      <td>Lampiran</td>
      <td>:</td>
    </tr>
    <tr>
      <td>Perihal</td>
      <td>: Agenda Pemeriksaan / Penilaian Lapangan / Pengambilan Contoh Produk</td>
    </tr>
  </table>

  Kepada Yth:
  
</div>
