<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <?php if($this->session->flashdata('status')!= ""){
        echo $this->session->flashdata('status');
      } ?>
      <table class="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Tanggal Pengajuan</th>
            <th>Jenis Layanan</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1;
          // header("Content-type: image/jpeg");
          foreach ($layanan as $layanan) { ?>
          <tr>
              <td><?= $i ?>.</td>
              <td><?php
              $tanggal = strtotime($layanan['tanggal_buat']);
              $bulan =date("m",$tanggal)-1;
              echo date("d",$tanggal)." ".$this->bulan[$bulan]." ".date("Y",$tanggal) ?></td>
              <td><?= $layanan['nama_layanan'] ?></td>
              <td><?php if($layanan['status'] == 0){ echo "Menunggu"; }else if($layanan['status'] == 1){echo "Ditolak";} ?></td>
              <td>
                <?php if($layanan['kekurangan'] != 0){ ?>
                  <a href="dashboard/dokumen_prima3/<?= $layanan['uid'] ?>" class="btn btn-info">Upload Dokumen</a>
                <?php }else{ echo "Dokumen telah diunggah";} ?>
                </td>
            </tr>
          <?php $i++;
          } ?>

        </tbody>
      </table>
    </div>
  </div>
</section>
