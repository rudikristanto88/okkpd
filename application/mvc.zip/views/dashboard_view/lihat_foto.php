<div class="container" style="margin-top:5px;">

<div class="row">
  <div class="col-2">&nbsp;</div>
  <div class="col-8">
    <?php
    
    echo '<img class="card-img-top" src="data:image/jpeg;base64,'.base64_encode( $file ).'" alt="Card image">' ?>
  </div>
  <div class="col-2">&nbsp;</div>
</div>
</div>
