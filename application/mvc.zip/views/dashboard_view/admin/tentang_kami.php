<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
          <ul class="breadcrumb breadcrumb-style">
            <li class="breadcrumb-item 	bcrumb-1">
              <a href="index.html">
                <i class="material-icons">home</i>
                Home</a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
              <li class="breadcrumb-item active">Tentang Kami</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Input -->
      <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="card">
            <div class="body">
              <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <strong>Tentang</strong> Kami</h2>
                        </div>
                        <div class="row">
                          <div class="col-md-4">
                            <div class="card">
                              <a href="<?= base_url('dashboard/pendaftaran/prima_3') ?>">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Visi dan Misi</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="card">
                              <a href="#">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Struktur Organisasi</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="card">
                              <a href="#">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Makumat</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="card">
                              <a href="#">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Tugas dan Fungsi</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="card">
                              <a href="#">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Legalitas</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="card">
                              <a href="#">
                                <div class="image-200">
                                  <img class="card-img-top " src="https://vignette.wikia.nocookie.net/geometry-wars/images/0/0e/Camera_icon.png/revision/latest?cb=20151005154117" alt="Card image">
                                </div>
                                <div class="card-body">
                                  <div class="text-center">
                                    <h4 class="card-title">Produk Hukum</h4>
                                  </div>
                                </div>
                              </a>

                            </div>
                          </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Table -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</section>
