<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <?php if($this->session->flashdata('status')!= ""){
        echo $this->session->flashdata('status');
      } ?>
      <table class="table">
        <thead>
          <tr>
            <th style="vertical-align: middle;">No</th>
            <th style="vertical-align: middle;">Nama User</th>
            <th style="vertical-align: middle;">Nama Perusahaan</th>
            <th style="vertical-align: middle;">Tanggal pengajuan</th>
            <th style="text-align: center;">Alasan Ditolak</th>
          </tr>

        </thead>
        <tbody>
          <?php $i=1; foreach ($dokumen as $dokumen) : ?>
            <tr>
              <td><?=$i ?>.</td>
              <td><?= $dokumen['nama_lengkap']?></td>
              <td><?= $dokumen['nama_usaha'] ?></td>
              <td><?= $dokumen['tanggal_pengajuan'] ?></td>
              <td><?= $dokumen['alasan_penolakan'] ?></td>
            </tr>

          <?php $i++;endforeach; ?>

        </tbody>
      </table>
    </div>
  </div>
</section>
