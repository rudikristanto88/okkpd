<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
          <ul class="breadcrumb breadcrumb-style">
            <li class="breadcrumb-item 	bcrumb-1">
              <a href="index.html">
                <i class="material-icons">home</i>
                Home</a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
              <li class="breadcrumb-item active">Identitas Usaha</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Input -->
      <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <a href="" class="btn btn-info">Ubah data</a><br/><br/>
          <table class="table">
              <tr>
                <th>Nama Usaha</th>
                <th>: <?=$usaha['nama_usaha'] ?></th>
              </tr>
              <tr>
                <th>Alamat Usaha</th>
                <th>: <?=$usaha['alamat_usaha']." RT ".$usaha['rt']." RW ".$usaha['rw']." Kec. ".$usaha['kecamatan']." Kel. ".$usaha['kelurahan'].", ".$usaha['kota']." Jawa Tengah" ?></th>
              </tr>
              <tr>
                <th>Nomor Telepon Usaha</th>
                <th>: <?=$usaha['no_telp'] ?></th>
              </tr>
              <tr>
                <th>Jenis Usaha</th>
                <th>: <?=$usaha['jenis_usaha'] ?></th>
              </tr>
              <tr>
                <th style="vertical-align:top">Foto KTP</th>
                <th>: <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $usaha['foto_ktp'] ).'" style="width:200px;"/>'; ?></th>
              </tr>
              <tr>
                <th>Foto NPWP</th>
                <th>: <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $usaha['foto_npwp'] ).'" style="width:200px;"/>'; ?></th>
              </tr>
              <tr>
                <th>Kop Surat</th>
                <th>: <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $usaha['kop_surat'] ).'" style="width:200px;"/>'; ?></th>
              </tr>

          </table>
      </div>
    </div>
    <!-- #END# Input -->


  </div>

</div>

<!-- Widgets -->

<!-- #END# Widgets -->

</div>
</section>


<script type="text/javascript">
function jenisUsaha(value){
  if(value == "perorangan"){
    document.getElementById("kop").style.display = "none";
    document.getElementById("kop_surat").value = "";
  }else{
    document.getElementById("kop").style.display = "block";

  }
}
</script>
