<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
          <ul class="breadcrumb breadcrumb-style">
            <li class="breadcrumb-item 	bcrumb-1">
              <a href="index.html">
                <i class="material-icons">home</i>
                Home</a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
              <li class="breadcrumb-item active">Identitas Usaha</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Input -->
      <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="card">
            <div class="body">
              <h2 class="card-inside-title">Daftar Usaha</h2>
              <?php
              $attribute = array("class"=>"text-white");
              echo form_open_multipart("dashboard/insert_identitas_usaha",$attribute);?>
              <div class="row clearfix">
                <div class="col-sm-12">
                  <div class="form-group">
                    <label for="jenis_usaha">Jenis Usaha</label>
                    <select class="col-12" name="jenis_usaha" onchange="jenisUsaha(this.value)" id="jenis_usaha">
                      <option value="Perusahaan">Perusahaan</option>
                      <option value="Kelompok">Kelompok</option>
                      <option value="Perorangan">Perorangan</option>
                    </select>
                  </div>
                </div>

                <div class="col-sm-12">
                  <div class="input-field">
                    <input id="nama_pemohon" name="nama_pemohon" type="text" class="text-white" data-length="10">
                    <label for="nama_pemohon">Nama Pemohon</label>
                  </div>
                </div>
                <div class="col-sm-12" id="kolom_jabatan">
                  <div class="input-field">
                    <input id="jabatan_pemohon" type="text" name="jabatan_pemohon" class="text-white" data-length="10">
                    <label for="jabatan_pemohon">Jabatan Pemohon</label>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="no_ktp_pemohon" type="text" name="no_ktp_pemohon" class="text-white"  data-length="10">
                    <label for="no_ktp_pemohon">Nomor KTP Pemohon</label>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <div class="file-field input-field">
                      <div class="btn">
                        <span>Upload File</span>
                        <input type="file" name="foto_ktp">
                      </div>
                      <div class="file-path-wrapper">
                        <input  class="file-path validate text-white" type="text" placeholder="Foto KTP">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="no_npwp" type="text" name="no_npwp" class="text-white"  data-length="10">
                    <label for="no_npwp">Nomor NPWP</label>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <div class="file-field input-field">
                      <div class="btn">
                        <span>Upload File</span>
                        <input type="file" name="foto_npwp">
                      </div>
                      <div class="file-path-wrapper">
                        <input  class="file-path validate text-white" type="text" placeholder="Foto NPWP">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="input-field">
                    <input id="nama_usaha" type="text" name="nama_usaha" class="text-white" data-length="10">
                    <label for="nama_usaha">Nama Perusahaan</label>
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="form-group">
                    <div class="form-line">
                      <div class="input-field">
                        <textarea id="alamat_usaha" class="materialize-textarea form-control no-resize text-white" name="alamat_usaha" data-length="120"></textarea>
                        <label for="alamat_usaha">Alamat Perusahaan</label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="input-field">
                    <input id="rt" type="number" name="rt" class="text-white" data-length="10">
                    <label for="rt">RT</label>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="input-field">
                    <input id="rw" type="number" name="rw" class="text-white" data-length="10">
                    <label for="rw">RW</label>
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="kota">Kota</label>
                    <select class="col-12" name="kota" onchange="jenisUsaha(this.value)" id="kota">
                      <?php foreach ($kota as $kota): ?>
                        <option value="<?= $kota['nama_kota'] ?>"><?= $kota['nama_kota'] ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="kecamatan">Kecamatan</label>
                    <select class="col-12" name="kecamatan" onchange="jenisUsaha(this.value)" id="kecamatan">
                      <option value="Perusahaan">Perusahaan</option>
                      <option value="Kelompok">Kelompok</option>
                      <option value="Perorangan">Perorangan</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="kelurahan">Kelurahan</label>
                    <select class="col-12" name="kelurahan" onchange="jenisUsaha(this.value)" id="kelurahan">
                      <option value="Perusahaan">Perusahaan</option>
                      <option value="Kelompok">Kelompok</option>
                      <option value="Perorangan">Perorangan</option>
                    </select>
                  </div>
                </div>


                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="no_telp" type="text" name="no_telp" class="text-white" data-length="10">
                    <label for="no_telp">Nomor Telepon Kantor</label>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="no_hp_pemohon" type="text" name="no_hp_pemohon" class="text-white" data-length="10">
                    <label for="no_hp_pemohon">Nomor HP Pemohon</label>
                  </div>
                </div>

                <div class="col-sm-12">
                  <div class="input-field">
                    <div class="file-field input-field">
                      <div class="btn">
                        <span>Upload File</span>

                        <input type="file" name="kop_surat">
                      </div>
                      <div class="file-path-wrapper">
                        <input  class="file-path validate text-white" type="text" placeholder="Kop Surat">
                      </div>
                    </div>

                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="nama_unit_kerja" type="text" name="nama_unit_kerja" class="text-white" data-length="10" readonly>
                    <label for="nama_unit_kerja">Nama Unit Kerja</label>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="input-field">
                    <input id="nama_pimpinan_unit_kerja" type="text" name="nama_pimpinan_unit_kerja" class="text-white" data-length="10" readonly>
                    <label for="nama_pimpinan_unit_kerja">Nama Pimpinan Unit Kerja</label>
                  </div>
                </div>

              </div>
              <button type="submit " class="btn btn-info waves-effect" name="button">Simpan</button>
            </form>

          </div>
        </div>
      </div>
    </div>
    <!-- #END# Input -->


  </div>

</div>

<!-- Widgets -->

<!-- #END# Widgets -->

</div>
</section>


<script type="text/javascript">
function jenisUsaha(value){
  if(value == "perorangan"){
    document.getElementById("kop").style.display = "none";
    document.getElementById("kop_surat").value = "";
  }else{
    document.getElementById("kop").style.display = "block";

  }
}
</script>
