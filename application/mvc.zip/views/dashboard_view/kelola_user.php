<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">
      <?php if($this->session->flashdata('status')!= ""){
        echo $this->session->flashdata('status');
      } ?>
      <table class="table">
        <thead>
          <tr>
            <th style="vertical-align: middle;">No</th>
            <th style="vertical-align: middle;">Nama Lengkap</th>
            <th style="vertical-align: middle;">Email (Username)</th>
            <th style="text-align: center;">Role</th>
          </tr>

        </thead>
        <tbody>
          <?php $i=1; foreach ($user as $user) : ?>
            <tr>
              <td><?=$i ?>.</td>
              <td><?= $user['nama_lengkap']?></td>
              <td><?= $user['username'] ?></td>
              <td><?= $user['nama_role'] ?></td>
            </tr>

          <?php $i++;endforeach; ?>

        </tbody>
      </table>
    </div>
  </div>
</section>
