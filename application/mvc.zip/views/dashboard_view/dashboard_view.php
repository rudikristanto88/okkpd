<section class="content">
  <div class="container-fluid">
    <div class="block-header" id="konten">

      <?php
      if($this->session->flashdata("status")){
        echo $this->session->flashdata("status");
      }
      ?>
asd
    </div>

    <!-- Widgets -->

    <!-- #END# Widgets -->

  </div>
</section>
