<div class="page_content">

    <section class="fullwidth_section news_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="sc_section">
                        <div class="sc_content container">
                            <div class="sc_blogger layout_news template_news sc_blogger_horizontal">
                                <div class="columns_wrap">


                                    <div class="container">
                                        <div class="post_item post_item_news sc_blogger_item sc_blogger_item_last">
                                            <h4 class="post_title sc_title sc_blogger_title">Legalitas</h4>
                                            <div class="post_content sc_blogger_content">
                                                <div class="post_descr">
                                                  <p>
                                                    OKKPD Provinsi Jateng ditetapkan sejak 10 Maret 2009 melalui Pergub Jateng No 20<br>
                                                    Tahun 2009 dan telah diubah beberapa kali terakhir dengan Pergub Jateng Nomor 23 Tahun 2017,<br>
                                                    tanggal 22 Mei 2017 tentang Pembentukan Otoritas Kompeten Keamanan Pangan Daerah Provinsi Jawa Tengah (OKKP-D Jawa Tengah).
                                                  </p>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>
