<section class="fullwidth_section no_padding_top_container news_section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="sc_section">
                    <div class="sc_section_overlay">
                        <div class="sc_section_content">
                            <div class="sc_content container">
                                <div class="sc_contact_form sc_contact_form_standard">
                                    <div class="sc_contact_form_left">
                                        <div class="sc_contact_info">
                                            <div class="sc_contact_form_address_wrap">
                                                <div class="sc_contact_form_address_field">
                                                    <span class="sc_contact_form_address_data">
                                                      <h4>Alamat Kantor</h4>
                                                        <br>Komplek Pertanian Tarubudaya
                                                        <br>Jl. Gatot Subroto, Ungaran Kabupaten Semarang
                                                    </span>
                                                </div>
                                                <div class="sc_contact_form_address_field">
                                                      <span class="sc_contact_form_address_label">Fax:</span>
                                                      <span class="sc_contact_form_address_data">024-6921997</span>
                                                  </div>
                                                  <div class="sc_contact_form_address_field">
                                                      <span class="sc_contact_form_address_label">Telpon:</span>
                                                      <span class="sc_contact_form_address_data">024-6921411</span>
                                                  </div>
                                                  <div class="sc_contact_form_address_field">
                                                      <span class="sc_contact_form_address_label">e-mail: </span>
                                                      <span class="sc_contact_form_address_data">foodsafety_bkpjateng@yahoo.com</span>
                                                  </div>
                                                  <div class="sc_contact_form_address_field">
                                                      <span class="sc_contact_form_address_label">
                                                        <img height="34" width="34" src="<?= base_url() ?>assets/default/WhatsApp_Logo_1.png" alt="Img WA">
                                                      </span>
                                                      <span class="sc_contact_form_address_data">+62 858-6581-3540</span>
                                                  </div>

                                            </div>
                                        </div>

                                    </div>
                                    <div class="sc_contact_form_right">
                                        <p class="sc_contact_form_description">Your email address will not be published. Required fields are marked *</p>
                                        <form data-formtype="contact" method="post" action="#">
                                            <div class="sc_contact_form_info">
                                                <div class="sc_contact_form_item sc_contact_form_field label_over">
                                                    <label class="required" for="sc_contact_form_username">Name</label>
                                                    <input id="sc_contact_form_username" type="text" name="username" placeholder="Name">
                                                </div>
                                                <div class="sc_contact_form_item sc_contact_form_field label_over">
                                                    <label class="required" for="sc_contact_form_email">E-mail</label>
                                                    <input id="sc_contact_form_email" type="text" name="email" placeholder="Email">
                                                </div>
                                                <div class="sc_contact_form_item sc_contact_form_field label_over">
                                                    <label class="required" for="sc_contact_form_subj">Subject</label>
                                                    <input id="sc_contact_form_subj" type="text" name="subject" placeholder="Subject">
                                                </div>
                                            </div>
                                            <div class="sc_contact_form_item sc_contact_form_message label_over">
                                                <label class="required" for="sc_contact_form_message">Message</label>
                                                <textarea id="sc_contact_form_message" name="message" placeholder="Message"></textarea>
                                            </div>
                                            <div class="sc_contact_form_item sc_contact_form_button">
                                                <button>
                                                    Send message
                                                    <span class="icon-mail-alt"></span>
                                                </button>
                                            </div>
                                            <div class="result sc_infobox"></div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</div>
