<ol class="breadcrumb">
<li><a href="#">Home</a></li>
<li><a href="#">Info Layanan</a></li>
</ol>
        <div class="page_content">
                <section class="fullwidth_section news_section">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="sc_section">
                                    <div class="sc_content container">
                                        <div class="sc_blogger layout_news template_news sc_blogger_horizontal">
                                            <div class="columns_wrap">
                                                <div class="col-sm-4 column_item_2">
                                                    <div class="post_item post_item_news sc_blogger_item">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Supply Chain Security" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/sertifikasi_prima_3"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Sertifikasi Prima 3</h4>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 column_item_1">
                                                    <div class="post_item post_item_news sc_blogger_item">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Air Freight Forwarding" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/sertifikasi_prima_2"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Sertifikasi Prima 2</h4>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 column_item_4">
                                                    <div class="post_item post_item_news sc_blogger_item sc_blogger_item_last">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Import Fundamentals" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/pendaftaran_psat"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Pendaftaran PSAT</h4>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="sc_section">
                                    <div class="sc_content container">
                                        <div class="sc_blogger layout_news template_news sc_blogger_horizontal">
                                            <div class="columns_wrap">
                                                <div class="col-sm-4 column_item_1">
                                                    <div class="post_item post_item_news sc_blogger_item">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Air Freight Forwarding" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/pendaftaran_rumah_kemas"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Pendaftaran Rumah Kemas</h4>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 column_item_2">
                                                    <div class="post_item post_item_news sc_blogger_item">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Supply Chain Security" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/penerbitan_health_certificate"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Penerbitan Health Certificate</h4>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 column_item_4">
                                                    <div class="post_item post_item_news sc_blogger_item sc_blogger_item_last">
                                                        <div class="post_featured">
                                                            <div class="post_thumb">
                                                                <img alt="Import Fundamentals" src="<?= base_url() ?>assets/default/images/news/400x250.png">
                                                                <div class="hover_wrap">
                                                                    <div class="link_wrap">
                                                                        <a class="hover_link icon-link" href="<?= base_url(); ?>home/penerbitan_hygne_sanitation"></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h4 class="post_title sc_title sc_blogger_title">Penerbitan Hygiene Sanitation</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
              </div>
