


            <div class="page_content">

                <section class="fullwidth_section news_section">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-3">
                              <div class="card">
                                <div class="card-body">
                                  <?php
                                    if($this->session->flashdata("status_registrasi") != null){
                                      echo $this->session->flashdata("status_registrasi");
                                    }
                                  ?>
                                  <h4>User Account</h4>
                                  <form class="" action="<?= base_url("verifikasi") ?>" method="post">
                                    <div class="form-container">
                                      <label for="">Username</label>
                                      <input type="text" name="username" value="" class="form-input form-block">
                                    </div>
                                    <div class="form-container">
                                      <label for="">Password</label>
                                      <input type="password" name="password" value="" class="form-input form-block">
                                    </div>
                                    <div class="form-container">
                                      <button type="submit" class="btn btn-primary btn-block" >Login</button>
                                    </div>
                                  </form>
                                    <span>Belum punya akun? <a href="<?= base_url('sign_up') ?>"><b>Buat akun</b></a></span><br/>
                                    <span ><a href="#">Lupa detail informasi masuk</a></span>

                                </div>
                              </div>

                            </div>
                        </div>
                    </div>
                </section>
</div>
