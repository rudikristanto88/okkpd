<?php
class Email extends CI_Controller {

    public function __construct()
  	{
  		parent::__construct();
  		$this->load->helper('url_helper');
  		$this->load->helper(array('form', 'url'));
      $this->load->library('session');
  		$this->load->library('email');



  	}
    // function Email()
    // {
    //     parent::Controller();
    //     $this->load->library('email');
    // }

    function index()
    {
        $config['protocol']    = 'smtp';
        $config['smtp_host']    = 'ssl://smtp.gmail.com';
        $config['smtp_port']    = '465';
        $config['smtp_timeout'] = '7';
        $config['smtp_user']    = 'mailer.okkpd@gmail.com';
        $config['smtp_pass']    = 'okkpd2018';
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or not

        $this->email->initialize($config);

        $this->email->from('mailer.okkpd@gmail.com', 'Sistem Notifikasi OKKPD JATENG');
        $this->email->to('oktadwi913@gmail.com');

        $this->email->subject('Email Test');
        $this->email->message('Testing the email class.');

        $this->email->send();

        echo'email terkirim';
    }
}
