<table width=100%>
<tr>
    <td align="left" rowspan='3' width='80px'><img width='80px' src='../assets/dashboard/images/dishanpan.png'></td>
</tr>
<tr>
    <td align="center"><p style="font-size:15px" align=center>PEMERINTAH PROVINSI JAWA TENGAH<br>
       DINAS KETAHANAN PANGAN PROVINSI JAWA TENGAH<br>OTORITAS KOMPETEN KEAMANAN PANGAN DAERAH
     </p>
     </td>
     <td align="left" rowspan='3' width='80px'><img width='80px' src='../assets/dashboard/images/jateng.png'></td>

</tr>
<tr>
    <td align="center"><p>Jl. Gatot Subroto - Ungaran, Telp. (024) 6922411 - 6923158, Fax. (024) 6921997</p></td>
</tr>
</table>
